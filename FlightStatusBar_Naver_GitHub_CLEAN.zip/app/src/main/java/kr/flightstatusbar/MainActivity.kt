package kr.flightstatusbar

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var priceText: TextView
    private lateinit var timeText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        priceText = findViewById(R.id.priceText)
        timeText = findViewById(R.id.timeText)

        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }

        findViewById<android.widget.Button>(R.id.startButton).setOnClickListener {
            ContextCompat.startForegroundService(this, Intent(this, PriceService::class.java))
        }
        findViewById<android.widget.Button>(R.id.stopButton).setOnClickListener {
            stopService(Intent(this, PriceService::class.java))
        }
    }
}
