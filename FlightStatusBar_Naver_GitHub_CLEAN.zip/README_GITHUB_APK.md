# GitHub에서 APK 만들기

1. GitHub에서 새 Repository를 만듭니다.
2. 이 ZIP의 파일과 폴더를 Repository에 업로드합니다.
3. Actions 탭을 엽니다.
4. Build APK 워크플로를 선택합니다.
5. Run workflow를 누릅니다.
6. 실행이 끝나면 해당 실행 화면 아래 Artifacts에서 FlightStatusBar-debug-apk를 눌러 APK ZIP을 받습니다.
7. ZIP 압축을 풀고 app-debug.apk를 갤럭시에 설치합니다.
