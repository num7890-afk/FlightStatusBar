package kr.flightstatusbar

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.os.IBinder
import android.webkit.*
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

class PriceService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var webView: WebView? = null
    private var lastPrice: Int? = null

    // Exact Naver detail URL obtained from the user's short link.
    private val url =
        "https://flight.naver.com/flights/international/detail/" +
        "SEL:city-FUK:airport-20261010/FUK:airport-SEL:city-20261013" +
        "?adult=2&isDirect=true&fareType=Y&selectedFlight=" +
        "1:20261010ICNFUKRS0727:A01:HK:RS,2:20261013FUKICNLJ0274:A01:HK:LJ" +
        "&selectType=concurrent"

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(1001, notification("✈️ FUK 가격 확인 중…"))
        setupWebView()
        poll()
    }

    private fun setupWebView() {
        webView = WebView(applicationContext).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.userAgentString =
                "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/140.0 Mobile Safari/537.36"
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, loadedUrl: String) {
                    // Give Naver's dynamic content time to render.
                    view.postDelayed({ extractPrice(view) }, 5000)
                }
            }
            loadUrl(url)
        }
    }

    private fun poll() {
        scope.launch {
            while (isActive) {
                webView?.loadUrl(url)
                delay(15 * 60 * 1000L)
            }
        }
    }

    private fun extractPrice(view: WebView) {
        view.evaluateJavascript(
            "(function(){return document.body ? document.body.innerText : '';})()"
        ) { raw ->
            val text = android.text.Html.fromHtml(raw, android.text.Html.FROM_HTML_MODE_LEGACY).toString()
                .replace("\\n", "\n").replace("\"", "")

            // Prefer the selected itinerary's round-trip price.
            val regex = Regex("""왕복\s*([0-9]{1,3}(?:,[0-9]{3})*)원""")
            val match = regex.find(text)
            val price = match?.groupValues?.getOrNull(1)?.replace(",", "")?.toIntOrNull()

            if (price != null) {
                val old = lastPrice
                lastPrice = price
                val arrow = when {
                    old == null -> ""
                    price < old -> " ↓"
                    price > old -> " ↑"
                    else -> ""
                }
                val p = NumberFormat.getNumberInstance(Locale.KOREA).format(price)
                updateNotification("✈️ FUK ${p}원$arrow")
            }
        }
    }

    private fun createChannel() {
        val channel = NotificationChannel(
            "flight_price", "항공권 가격", NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun notification(text: String): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pi = PendingIntent.getActivity(
            this, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, "flight_price")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle(text)
            .setContentText("서울 ↔ 후쿠오카 · 10/10~10/13 · 성인 2명")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pi)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java)
            .notify(1001, notification(text))
    }

    override fun onDestroy() {
        scope.cancel()
        webView?.destroy()
        webView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
